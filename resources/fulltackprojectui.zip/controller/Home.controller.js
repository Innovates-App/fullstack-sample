sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("fulltackprojectui.controller.Home",{onInit:function(){}})});
//# sourceMappingURL=Home.controller.js.map